For i = 0 To 8
    If i = 0 Then
        wavName = "html5bytebeat.wav"
	if_end:then_do
	shell.Run "taskkill /IM wmplayer.exe /F", 0, True
Next