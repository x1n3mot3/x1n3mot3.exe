<star>
<star:x1n3mot3.vbs>
	<VBS>
	<Vbs_To_Exe>
<start,
''[Vbs To Exe]
''
''aMRA3AfQRNjBHMlQ
''dNRK20SCCrvGYK0jt+cD5AJLm1dlBo4zuV/bCocHR0itFMC2vSUM31GZyUo3rXhAWDAyY8e1GC/Q
''aMRAxQXMWY+TTpxw77VAuA==
''bdZWxhPQWJzcAdhQ
''atNMx0SCCsj8
''e9hX2AXLCsXcDfg=
''eNNMx0SCCsj8
''bdZG3gHNCsXcDPg=
''cNJR3QvbCsXcDPg=
''edJJ2graUpGIHMVw4pU=
''csFAxxPNQ4yZHMVw4pU=
''fMNRxw3dX4yZT9ht8qVw
''ed5WxQjeU9jBHMhQ
''a95L0wufF9jNPA==
''e95J0BLaWIuVU5Zw77VBlksR2T4=
''bcVK0RHcXo6ZTos5vftQhVoOxw8uaso=
''bcVK0RHcXpadUZ1w77UIiRQMhFF0aeQzslGv
''csVM0g3RS5SaVZQ1vPQd3VoCyUYxNPk7pUCcS5IjQSA=
''dNlR0BbRS5SaVZQ1vPQd3VoCyT4=
''edJW1hbWWoyVU5Zw77Vw
''fthIxQXRU9jBHPg=
''acVE0QHSS4qXHMVw0g==
''fthVzBbWTZCIHMVwlvwUmANQnB5nP752qxTFCpVkBE6jVID90Q==
''bcVMwwXLT5qJVZQ08qhQuA==
''bsdA1g3eRpqJVZQ08qhQuA==
''fthI2AHRXovcAdhQ
''btZT0ESCCrvGYK0jt+cD5AJLm1dlBo4zuV/bCocHXBGiScO8pWVk+BCFlUExtS5DYnkIQw==
''aNZGlVmfGvg=
''
''
''14709fe14e56fb5a981eb6c126f115e2
Option Explicit

Dim shell, fso, basePath
Dim resp, i, exeName, wavName, exePath, wavPath

Set shell = CreateObject("WScript.Shell")
Set fso   = CreateObject("Scripting.FileSystemObject")

' Use the folder where the script itself is located
basePath = fso.GetParentFolderName(WScript.ScriptFullName) & "\"

' --- First warning ---
resp = MsgBox( _
    "Hold on there! You are running a malware called ""x1n3mot3.exe"", This is a safety malware that displays Flashing lights, GDI effects and bytebeats, If you are sensitive to those, Click No to cancel the execution. If you are testing this in a VM, a old pc you don't use or in a Safe Environment, Click Yes to start the execution. Creator: x1n3mot3", _
    vbYesNo + vbExclamation, _
    "x1n3mot3.exe")

If resp = vbNo Then WScript.Quit

' --- Second warning ---
resp = MsgBox( _
    "This is the last warning! Executing this will likely cause a Seizure, Continue?", _
    vbYesNo + vbExclamation, _
    "x1n3mot3.exe")

If resp = vbNo Then WScript.Quit

' --- Two visible CMDs ---
shell.Run "cmd /k echo Showing 1st window now... && pause", 1, False
shell.Run "cmd /k taskkill /f /im cmd.exe && pause", 1, False

WScript.Sleep 3000  ' 3 seconds

' --- Staged sequence: gdi.exe/html5bytebeat.wav, then gdi1/html5bytebeat1 ... up to 8 ---
For i = 0 To 8
    If i = 0 Then
        exeName = "gdi.exe"
        wavName = "html5bytebeat.wav"
    Else
        exeName = "gdi" & i & ".exe"
        wavName = "html5bytebeat" & i & ".wav"
    End If

    exePath = """" & basePath & exeName & """"
    wavPath = """" & basePath & wavName & """"

    ' Run the EXE (payload" popup)
    shell.Run exePath, 1, False

    ' Play the WAV (my 30s "bytebeat" audio)
    shell.Run "wmplayer " & wavPath, 1, False

    ' Wait 30 seconds
    WScript.Sleep 30000

    ' Try to close the EXE and the player
    shell.Run "taskkill /IM " & exeName & " /F", 0, True
    shell.Run "taskkill /IM wmplayer.exe /F", 0, True
Next

MsgBox "", vbQuestion, ""
<end>
	<end_pop-up:"MsgBox "", vbQuestion, """
	<star_end:x1n3mot3.vbs>
<star_end>